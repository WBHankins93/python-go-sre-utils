# Log Alert Agent

A Python CLI tool that parses log files, detects errors and warnings, classifies them by severity, and exports summaries.

## Features
- Supports plain text, JSON, and NDJSON logs
- Detects errors and warnings using keyword/pattern matching
- Classifies alerts as High / Medium / Low
- Outputs results in Markdown, CSV, or JSON
- Optional Slack webhook integration (coming soon)

## Usage
```bash
python main.py sample_logs/sample-app.log --format md
```